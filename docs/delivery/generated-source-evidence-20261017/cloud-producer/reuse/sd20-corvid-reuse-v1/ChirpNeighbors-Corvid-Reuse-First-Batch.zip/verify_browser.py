from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from threading import Thread
from playwright.sync_api import sync_playwright
import json,hashlib,time
P=Path(__file__).parent
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(P)))
Thread(target=server.serve_forever,daemon=True).start();errors=[]
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1250,'height':1300});page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{server.server_port}/review.html');page.wait_for_function('Array.from(document.images).every(i=>i.complete&&i.naturalWidth>0)')
  images=page.locator('img');sizes=images.evaluate_all('(a)=>a.map(i=>({cssWidth:i.clientWidth,cssHeight:i.clientHeight,naturalWidth:i.naturalWidth,naturalHeight:i.naturalHeight}))');assert [s['cssWidth'] for s in sizes]==[192,384,216,432]
  raven=images.nth(2);samples=[];start=time.monotonic()
  for target in [0,1.45,2.4,3.05,3.75,4.3]:
   page.wait_for_timeout(max(0,(target-(time.monotonic()-start))*1000));samples.append({'elapsedMs':round((time.monotonic()-start)*1000),'browserPixelSha256':hashlib.sha256(raven.screenshot()).hexdigest()})
  assert len({s['browserPixelSha256'] for s in samples})>=3 and not errors
  browser.close()
 (P/'browser-verification.json').write_text(json.dumps({'method':'actual Chromium native APNG playback at proposed CSS size; six timestamped raster samples, no continuous human video review','sizes':sizes,'ravenSamples':samples,'distinctRavenBrowserStates':len({s['browserPixelSha256'] for s in samples}),'pageErrors':errors,'actualYardIntegration':False,'screenshotsSavedOrPublished':False},indent=2)+'\n')
finally:server.shutdown();server.server_close()
