from pathlib import Path
from PIL import Image
import json,hashlib,struct,math,numpy as np
P=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
results=[]
for species,name,edge in [('american_crow','crow-walk-v2',192),('common_raven','raven-idle',216)]:
 p=P/species;m=json.loads((p/'texture-review-manifest.json').read_text());line=json.loads((p/'source-lineage.json').read_text());atlas=Image.open(p/'atlas.png').convert('RGBA');src=Image.open(P/'sources'/f'{name}.source.png').convert('RGBA')
 assert sha((P/'sources'/f'{name}.source.png').read_bytes())==json.loads((P/'sources'/f'{name}.metadata.json').read_text())['packageData']['manifest']['source']['sha256']
 assert m['source']['sha256']==sha((p/'atlas.png').read_bytes())
 assert atlas.width<=1024 and atlas.height<=1024 and atlas.width*atlas.height<=1048576
 assert len((p/'atlas.png').read_bytes())<=4194304 and len((p/'texture-review-manifest.json').read_bytes())<=65536
 for i,lin in enumerate(line['lineage']):
  r=lin['canonicalSourceRect'];c=src.crop((r['x'],r['y'],r['x']+r['width'],r['y']+r['height']));expected=c.resize((edge,edge),Image.Resampling.NEAREST);out=Image.open(p/'frames'/f'{i}.png').convert('RGBA')
  assert expected.tobytes()==out.tobytes() and sha((p/'frames'/f'{i}.png').read_bytes())==lin['outputPngSha256']
 for f in m['frames']:
  r=f['sourceRect'];im=atlas.crop((r['x'],r['y'],r['x']+r['width'],r['y']+r['height']));assert f['world']['width']*f['sourcePixelsPerWorldUnit']==edge
  assert all(im.getpixel((c['x'],c['y']))[3]>0 for c in f['contacts'])
  assert f['pivot']==m['frames'][0]['pivot'] and f['contacts']==m['frames'][0]['contacts']
 ids={f['id'] for f in m['frames']};assert all(s['frameId'] in ids and 1<=s['durationTicks']<=300 for c in m['clips'] for s in c['frames'])
 im=Image.open(p/'idle.apng');dur=[]
 for i in range(im.n_frames):im.seek(i);dur.append(im.info.get('duration'))
 if len(m['frames'])>1:
  assert im.n_frames==len(m['clips'][0]['frames']);assert all(abs(a-b['durationTicks']/30*1000)<.001 for a,b in zip(dur,m['clips'][0]['frames']))
 results.append({'species':species,'sourceAtlasHashVerified':True,'exactFullCanvasNearestExportsVerified':len(line['lineage']),'idleUniqueImages':len(m['frames']),'allIdleContactsPositiveAlpha':True,'commonIdleGeometryAndContacts':True,'profileStructuralAndBudgetChecks':True,'actualZodSharpIntakeExecuted':False,'apngDecodedFrames':im.n_frames,'decodedDurationsMs':dur,'sourceAtlasSha256':sha((P/'sources'/f'{name}.source.png').read_bytes())})

# Semantic contact diagnostic for raven; threshold/region proxy, not toe tracking.
feet=[]
for i in range(4):
 a=np.array(Image.open(P/'common_raven/frames'/f'{i}.png'));y,x=np.indices(a.shape[:2]);frame=[]
 for side in [x<134,x>=134]:
  yy,xx=np.where((a[:,:,3]>=128)&side&(x>=104)&(x<=169)&(y>=162)&(y<=174));frame.append({'bottomBoundary':int(yy.max()+1),'centroid':[float(xx.mean()),float(yy.mean())],'count':len(xx)})
 feet.append(frame)
baseline=max(abs(a['bottomBoundary']-b['bottomBoundary']) for af in feet for bf in feet for a,b in zip(af,bf));centroid=max(math.dist(a['centroid'],b['centroid']) for af in feet for bf in feet for a,b in zip(af,bf))
receipt={'checks':results,'ravenFootRasterDiagnostic':{'method':'alpha>=128 output region x104..169,y162..174 splitx134; not anatomical toe tracking','frames':feet,'maxPerFootGroundBoundaryChangeOutputPx':baseline,'maxPixelCentroidChangeOutputPx':centroid,'worldUnitsAtProposedDensity1':baseline,'interpretation':'small drawn/raster foot changes; no actor root movement tested; common positive alpha alone does not prove physical contact'},'generationCalls':0,'newDrawings':0,'runtimeAdmissionPerformed':False}
(P/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
