from pathlib import Path
from PIL import Image, ImageDraw
import json, hashlib, base64

ROOT=Path(__file__).parent
COMMIT='63654eae4538f79420b1f802ec12ca49b385054d'
def sha(b):return hashlib.sha256(b).hexdigest()
def fid(im):return 'frame.sha256.'+sha(('RGBA8;%dx%d;'%im.size).encode()+im.tobytes())
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
records=[]
for species,source,edge,pivot,contacts,steps in [
 ('american_crow','crow-walk-v2',192,[127,150],[[96,147],[155,143]],[(0,90)]),
 ('common_raven','raven-idle',216,[144,174],[[119,167],[152,167]],[(0,42),(1,3),(0,25),(2,16),(3,20),(0,20)])]:
 out=ROOT/species;out.mkdir(exist_ok=True);(out/'frames').mkdir(exist_ok=True)
 p=ROOT/'sources'/f'{source}.source.png';src=Image.open(p).convert('RGBA')
 meta=json.loads((ROOT/'sources'/f'{source}.metadata.json').read_text())
 lineage=[];frames=[];source_frames=[]
 for i,f in enumerate(meta['packageData']['manifest']['frames']):
  r=f['sourceRect'];s=src.crop((r['x'],r['y'],r['x']+r['width'],r['y']+r['height']))
  canvas=Image.new('RGBA',(f['canvas']['width'],f['canvas']['height']));canvas.paste(s,(f['trim']['x'],f['trim']['y']))
  im=canvas.resize((edge,edge),Image.Resampling.NEAREST);frames.append(im);source_frames.append(canvas)
  im.save(out/'frames'/f'{i}.png')
  lineage.append({'index':i,'canonicalSourceFrameId':fid(canvas),'canonicalSourceFrameDimensions':list(canvas.size),'canonicalSourceRect':r,'canonicalTrim':f['trim'],'canonicalSourceAtlasSha256':sha(p.read_bytes()),'outputFrameId':fid(im),'outputPngSha256':sha((out/'frames'/f'{i}.png').read_bytes()),'outputRgbaSha256':sha(im.tobytes()),'operation':'one uniform nearest resize of existing full canvas; no pixel paint, threshold, fitting, recoloring or new drawings','sourceToOutputScale':edge/canvas.width,'visibleAlpha128Bounds':list(im.getchannel('A').point(lambda a:255 if a>=128 else 0).getbbox())})
 chosen=frames if species=='common_raven' else frames[:1]
 atlas=Image.new('RGBA',(len(chosen)*edge,edge))
 for i,im in enumerate(chosen):atlas.paste(im,(i*edge,0))
 atlas.save(out/'atlas.png')
 manifest={'schemaVersion':1,'profile':'chirp-texture-review-v1','scope':'review-only','approval':'unreviewed','activation':'none','source':{'sha256':sha((out/'atlas.png').read_bytes()),'creator':'Chirp existing canonical corvid source reuse','tool':'Pillow nearest full-canvas export','toolVersion':Image.__version__,'rights':'unreviewed','fidelity':'unreviewed'},'atlas':{'width':atlas.width,'height':atlas.height,'alpha':'straight-rgba8','colorSpace':'srgb'},'frames':[],'clips':[{'id':'idle','tickRate':30,'loop':True,'frames':[{'frameId':f'{species}-{i}','durationTicks':ticks} for i,ticks in steps]}]}
 for i,im in enumerate(chosen):
  manifest['frames'].append({'id':f'{species}-{i}','sourceRect':{'x':i*edge,'y':0,'width':edge,'height':edge},'canvas':{'width':edge,'height':edge},'trim':{'x':0,'y':0},'pivot':{'x':pivot[0],'y':pivot[1]},'contacts':[{'id':f'foot-{n}-review','x':c[0],'y':c[1]} for n,c in enumerate(contacts)],'world':{'width':edge,'height':edge},'sourcePixelsPerWorldUnit':1})
 dump(out/'texture-review-manifest.json',manifest)
 # APNG supports rational timing; the manifest's30Hz ticks remain authoritative.
 seq=[frames[i] for i,t in steps];dur=[t*1000/30 for i,t in steps]
 seq[0].save(out/'idle.apng',save_all=True,append_images=seq[1:],duration=dur,loop=0,disposal=0,blend=0)
 rgb=[]
 for im in seq:
  bg=Image.new('RGBA',im.size,(230,225,205,255));bg.alpha_composite(im);rgb.append(bg.convert('RGB'))
 rgb[0].save(out/'idle.gif',save_all=True,append_images=rgb[1:],duration=[round(d/10)*10 for d in dur],loop=0)
 if species=='american_crow':
  move=Image.new('RGBA',(edge*4,edge))
  for i,im in enumerate(frames):move.paste(im,(i*edge,0))
  move.save(out/'moving-draft-atlas.png')
  bg=[]
  for im in frames:
   b=Image.new('RGBA',im.size,(230,225,205,255));b.alpha_composite(im);bg.append(b.convert('RGB'))
  bg[0].save(out/'moving-draft.gif',save_all=True,append_images=bg[1:],duration=[170,200,170,200],loop=0)
  dump(out/'moving-draft.json',{'status':'not admitted; contact trajectory and weak near/far alternation unresolved','frameIndices':[0,1,2,3],'durationTicks':[5,6,5,6],'tickRate':30,'rootTrajectory':None,'behaviorBound':False,'visuallyVerifiedInApp':False,'source':'existing four drawings; no synthetic or newly drawn frames'})
  moving=json.loads(json.dumps(manifest));moving['atlas']={'width':edge*4,'height':edge,'alpha':'straight-rgba8','colorSpace':'srgb'};moving['source']['sha256']=sha((out/'moving-draft-atlas.png').read_bytes());moving['frames']=[]
  for i,im in enumerate(frames):
   f=json.loads(json.dumps(manifest['frames'][0]));f['id']=f'{species}-{i}';f['sourceRect']['x']=i*edge
   old=meta['packageData']['manifest']['frames'][i]['contacts']
   f['contacts']=[{'id':c['id'],'x':int(c['x']/2),'y':int(c['y']/2)} for c in old]
   # Preserve requested nearby marker; choose nearest actual positive-alpha pixel.
   for c in f['contacts']:
    if im.getpixel((c['x'],c['y']))[3]==0:
     options=[(x,y) for y in range(max(0,c['y']-3),min(edge,c['y']+4)) for x in range(max(0,c['x']-3),min(edge,c['x']+4)) if im.getpixel((x,y))[3]>0]
     x,y=min(options,key=lambda p:(p[0]-c['x'])**2+(p[1]-c['y'])**2);c.update(x=x,y=y)
   moving['frames'].append(f)
  moving['clips'].append({'id':'moving','tickRate':30,'loop':True,'frames':[{'frameId':f'{species}-{i}','durationTicks':t} for i,t in enumerate([5,6,5,6])]})
  dump(out/'moving-draft-texture-review-manifest.json',moving)
 dump(out/'source-lineage.json',{'repository':'patanet7/ChirpNeighbors','sourceCommit':COMMIT,'sourceName':source,'sourceReviewExportPath':f'assets/generated/2026-10-17/pipeline/candidate-yard/corvid-{source}-standalone-v2.review.json','lineage':lineage,'newDrawingCount':0,'existingDrawingsRead':len(frames),'idleUniqueDrawingsUsed':len(chosen),'canonicalSharpReceiptForThisExport':None,'note':'Historical source receipt retained in sources metadata only. Derived atlas must be processed anew through Mac canonical Sharp intake.'})
 records.append({'species':species,'canvasWorldUnits':[edge,edge],'sourceCanvas384ToOutputScale':edge/384,'densityOutputPixelsPerWorldUnit':1,'firstPoseVisibleSize':[lineage[0]['visibleAlpha128Bounds'][2]-lineage[0]['visibleAlpha128Bounds'][0],lineage[0]['visibleAlpha128Bounds'][3]-lineage[0]['visibleAlpha128Bounds'][1]],'pivot':pivot,'contacts':contacts,'idleTicks':sum(t for i,t in steps),'idleSteps':steps,'idleSourceIds':[lineage[i]['canonicalSourceFrameId'] for i in range(len(chosen))],'idlePlanned':True,'idleExportPrepared':True,'idleBoundInApp':False,'idleVisuallyVerifiedInApp':False,'movementPlanned':True,'movementBoundInApp':False,'interactionPlanned':'object inspection: stop, look toward a ground food/object; no ingestion or beak-contact animation claimed','interactionBoundInApp':False,'fallback':'single corrected-charcoal stride pose held still; not a newly drawn neutral standing pose' if species=='american_crow' else 'hold frame0 if temporal flicker is distracting','artStatus':'owner provisional tolerance applies; no blanket final roster acceptance','scaleStatus':'proposed presentation scale, not biological size approval','contactStatus':'positive alpha review markers, not anatomical/toe tracking or tested world contact'})
dump(ROOT/'intake.json',{'sourceCommit':COMMIT,'newGenerationCalls':0,'newDrawings':0,'runtimeAdmissionPerformed':False,'canonicalSharpReceiptPendingOnMac':True,'candidates':records,'scaleReference':{'AmericanCrowLengthCm':[40,53],'CommonRavenLengthCm':[56,69],'midpointLengthRatio':62.5/46.5,'renderedFirstPoseWidthRatio':records[1]['firstPoseVisibleSize'][0]/records[0]['firstPoseVisibleSize'][0],'sources':['https://www.allaboutbirds.org/guide/American_Crow/id','https://www.allaboutbirds.org/guide/Common_Raven/id'],'interpretation':'preserved canonical source references; approximate display calibration only; image pose and tail foreshortening change width'}})

# Self-contained primary idle preview, actual proposed CSS/world scale and a zoom.
cards=[]
for r in records:
 s=r['species'];data=base64.b64encode((ROOT/s/'idle.apng').read_bytes()).decode();e=r['canvasWorldUnits'][0]
 cards.append(f'<section><h2>{s.replace("_"," ").title()}</h2><p>{r["firstPoseVisibleSize"]} visible px; {e}px canvas at density1. Export prepared; app binding and yard verification pending.</p><img width="{e}" height="{e}" src="data:image/png;base64,{data}"><img style="margin-left:24px" width="{e*2}" height="{e*2}" src="data:image/png;base64,{data}"><p>{r["fallback"]}. Contacts are provisional positive-alpha markers.</p></section>')
 (ROOT/'review.html').write_text('<!doctype html><meta charset="utf-8"><title>Corvid reuse review</title><style>body{font:16px system-ui;background:#e6e1cd;color:#24251e;padding:24px}img{image-rendering:pixelated;vertical-align:bottom}section{border-top:1px solid #aaa;padding:16px 0}p{max-width:850px}</style><h1>Existing crow and raven sources — proposed normal size</h1><p>Left: proposed output/world scale at1CSS pixel per worldunit. Right:2× inspection. No generation; no runtime integration. Raven uses actual blink and look drawings. Crow holds one existing stride drawing; movement draft remains separate.</p>'+''.join(cards))
print(json.dumps(records,indent=2))
