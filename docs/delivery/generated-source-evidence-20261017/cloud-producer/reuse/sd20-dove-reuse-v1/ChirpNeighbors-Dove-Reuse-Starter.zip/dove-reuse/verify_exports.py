from pathlib import Path
from PIL import Image
import json,hashlib,struct
P=Path(__file__).parent;R=P.parent.parent;sha=lambda b:hashlib.sha256(b).hexdigest();h=json.loads((P/'handoff.json').read_text());checks=[]
for e in h['exports']:
 m=json.loads((P/e['manifest']).read_text());atlas=Image.open(P/e['atlas']).convert('RGBA');assert sha((P/e['atlas']).read_bytes())==m['source']['sha256'];assert atlas.width<=1024 and atlas.height<=1024
 assert m['profile']=='chirp-texture-review-v1' and m['approval']=='unreviewed' and m['activation']=='none'
 for f,l in zip(m['frames'],e['frames']):
  src=Image.open(R/l['sourceFile']).convert('RGBA');im=Image.open(P/l['outputFile']).convert('RGBA');assert sha((R/l['sourceFile']).read_bytes())==l['sourcePNGsha256'];assert 'frame.sha256.'+sha(f'RGBA8;{src.width}x{src.height};'.encode()+src.tobytes())==l['sourceFrameId'];assert im.tobytes()==src.resize((192,192),Image.Resampling.NEAREST).tobytes();assert sha((P/l['outputFile']).read_bytes())==l['outputPNGsha256'];rect=f['sourceRect'];assert im.tobytes()==atlas.crop((rect['x'],rect['y'],rect['x']+192,rect['y']+192)).tobytes()
  for c in f['contacts']:assert im.getpixel((c['x'],c['y']))[3]>=128
  assert f['pivot']=={'x':105,'y':150} and f['canvas']==f['world']=={'width':192,'height':192} and f['sourcePixelsPerWorldUnit']==1
 assert len(m['clips'][0]['frames'])==1 # current normal-yard opt-in sees the honest neutral.
 data=(P/e['preview']).read_bytes();p=8;delays=[]
 while p<len(data):
  n=struct.unpack('>I',data[p:p+4])[0];k=data[p+4:p+8];d=data[p+8:p+8+n];p+=12+n
  if k==b'fcTL':delays.append(struct.unpack('>IIIIIHHBB',d)[5:7])
 assert delays==[(t,30) for t in e['ticks']]
 with Image.open(P/e['preview']) as im:
  assert im.n_frames==len(e['timelineFrameIndices'])
  for k,idx in enumerate(e['timelineFrameIndices']):im.seek(k);assert im.convert('RGBA').tobytes()==Image.open(P/e['frames'][idx]['outputFile']).convert('RGBA').tobytes()
 checks.append(e['id'])
assert h['newDrawings']==h['runtimeBindingsCreated']==0
result={'passed':True,'exports':checks,'checks':['exactsourcePNGanddecodedRGBAIDs','all192wholecanvasnearestexports','atlasroundtrips','allfootproxiespositivealpha128','singleuniformcanvas/pivot/worlddensity','exactAPNGticktiminganddecodedframes','neutralonlyidleclip','noimplementedbehavior/newdrawingclaim'],'fullMacSharpZodValidation':False,'physicalContactApproval':False};(P/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
